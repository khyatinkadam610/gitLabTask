const express = require('express');
const bodyParser = require('body-parser');
const https = require('https');
const handlebars = require('handlebars');
const fs = require('fs');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form.html');
});

app.post('/submit-form', (req, res) => {
    const privateToken = req.body.token;
    const projectId = req.body.id;
    const startDate = req.body.start;
    const endDate = req.body.end;

    const gitlabOptions = {
        hostname: 'gitlab.com',
        path: `/api/v4/projects/${projectId}/repository/commits?first_parent=true&since=${startDate}T00:00:00Z&until=${endDate}T23:59:59Z&with_stats=true`,
        
        method: 'GET',
        headers: {
            'PRIVATE-TOKEN': `${privateToken}`
            // 'PRIVATE-TOKEN': 'glpat-m_btkx8x7_-A456fT1aN',
        },
    };

    const gitlabRequest = https.request(gitlabOptions, (gitlabResponse) => {
        let data = '';

        gitlabResponse.on('data', (chunk) => {
            data += chunk;
        });

        gitlabResponse.on('end', () => {
            const jsonData = JSON.parse(data);

            const users = {};
            jsonData.forEach((commit) => {
                const author = commit.author_name;
                if (!users[author]) {
                    users[author] = {
                        name: author,
                        additions: 0,
                        deletions: 0,
                        total: 0,
                    };
                }
                users[author].additions += commit.stats.additions;
                users[author].deletions += commit.stats.deletions;
                users[author].total += commit.stats.total;
            });

            const userData = Object.values(users);

            const html = fs.readFileSync('table.html', 'utf8');
            const template = handlebars.compile(html);
            const renderedHtml = template({ users: userData });

            res.send(renderedHtml);
        });
    });

    gitlabRequest.on('error', (error) => {
        console.error(error);
    });

    gitlabRequest.end();
});

app.listen(3000, () => {
    console.log('Server started on port 3000');
});