const express = require('express');
const bodyParser = require('body-parser');
const https = require('https');
const handlebars = require('handlebars');
const fs = require('fs');
const {Octokit} = require("@octokit/rest");
const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/form1.html');
});

app.post('/submit-form', async (req, res) => {
  console.log(req);
    const repo = req.body.repo
    const owner = req.body.owner;
    const privateToken = req.body.token;
   
    // const projectId = req.body.id;
    // const startDate = req.body.start;
    // const endDate = req.body.end;
    
    const octokit = new Octokit({
        auth: `${privateToken}`
      })
    //   https://api.github.com/repos/khyatinkadam610/pmc_angular/stats/commits?since=2022-01-01T00:00:00Z&until=2023-04-06T00:00:00Z
      await octokit.request('GET /repos/{owner}/{repo}/commits?since=2022-01-01T00:00:00Z&until=2023-04-08T00:00:00Z', {
        owner: `${owner}`,
        repo: `${repo}`,
        headers: {
          'X-GitHub-Api-Version': '2022-11-28'
        }
      })

    const githubRequest = https.request(octokit, (githubResponse) => {
        let data = '';

        githubResponse.on('data', (chunk) => {
            console.log(chunk);
            data += chunk;
        });

        githubResponse.on('end', () => {
            const jsonData = JSON.parse(data);
            console.log(jsonData);
            // const users = {};
            // jsonData.forEach((commit) => {
            //     const author = commit.author_name;
            //     if (!users[author]) {
            //         users[author] = {
            //             name: author,
            //             additions: 0,
            //             deletions: 0,
            //             total: 0,
            //         };
            //     }
            //     users[author].additions += commit.stats.additions;
            //     users[author].deletions += commit.stats.deletions;
            //     users[author].total += commit.stats.total;
            // });

            // const userData = Object.values(users);

            // const html = fs.readFileSync('table.html', 'utf8');
            // const template = handlebars.compile(html);
            // const renderedHtml = template({ users: userData });

            // res.send(renderedHtml);
        });
    });

    githubRequest.on('error', (error) => {
        console.error(error);
    });

    githubRequest.end();
});

app.listen(3000, () => {
    console.log('Server started on port 3000');
});